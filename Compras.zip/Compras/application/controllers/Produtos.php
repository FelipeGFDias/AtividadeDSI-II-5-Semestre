<?php
defined('BASEPATH') OR exit('No direct script access allowed');

Class Produtos extends CI_Controller {
    //Atributos privados da classe
    private $codigo;
    private $descricao;
    private $unidMedida;
    private $estoqMinimo;
    private $estoqMaximo;
    private $dtCria;
    private $usuarioLogin;
    private $estatus;

    //Getters dos atributos
    public function getCodigo()
	{
		return $this->codigo;
	}

    public function getDescricao()
    {
        return $this->descricao;
    }

    public function getUnidMedida()
    {
        return $this->unidMedida;   
    }

    public function getEstoqMinimo()
    {
        return $this->estoqMinimo;
    }

    public function getEstoqMaximo()
    {
        return $this->estoqMaximo;
    }

    public function getDtCria()
    {
        return $this->dtCria;
    }

    public function getUsuarioLogin()
    {
        return $this->usuarioLogin;
    }

    public function getEstatus()
    {
        return $this->estatus;
    }

    //Setters dos atributos
    public function setCodigo($codigoFront)
	{
		$this->codigo = $codigoFront;
	}

    public function setDescricao($descricaoFront)
    {
        $this->descricao = $descricaoFront;
    }

    public function setUnidMedida($unidMedidaFront) 
    {
        $this->unidMedida = $unidMedidaFront;
    }

    public function setEstoqMinimo($estoqMinimoFront)
    {
        $this->estoqMinimo = $estoqMinimoFront;
    }

    public function setEstoqMaximo($estoqMaximoFront)
    {
        $this->estoqMaximo = $estoqMaximoFront;
    }

    public function setDtCria($dtCriaFront)
    {
        $this->dtCria = $dtCriaFront;
    }

    public function setUsuarioLogin($usuarioLoginFront)
    {
        $this->usuarioLogin = $usuarioLoginFront;
    }

    public function setEstatus($estatusFront)
    {
        $this->estatus = $estatusFront;
    }

    Public function inserir(){
        //Descrição, Unidade de medida, Estoque máximo, Estoque mínimo e Descrição
		//recebidas via JSON e colocadas em variáveis
		//Retornos possíveis:
		//1 - Produto cadastrado corretamente (Banco)
		//2 - Faltou informar a Unidade de medida (FrontEnd)		
		//3 - Unidade de medida não encontrada no banco de dados (Banco)
		//4 - Descrição não informada (FrontEnd)
		//5 - Usuário não informado (FrontEnd)
		//6 - Houve algum problema no insert da tabela (Banco)
		//7 - Houve problema no salvamento do LOG, mas a unidade foi inclusa (LOG)
		//8 - Usuário desativado no banco de dados
		//9 - Usuário não encontrado
		//10 - Unidade de medida já cadastrada na base de dados (Model)
        //11 - Estoque mínimo não informado (FrontEnd)	
        //12 - Estoque maximo não informado (FrontEnd)
        //13 - Estoque maximo e minimo iguais (FrontEnd)

        try{
            $json = file_get_contents('php://input');
			$resultado = json_decode($json);

            //Array com os dados que deverão vir do Front
			$lista = array(
				"descricao" => '0',
                "unidMedida" => '0',
                "estoqMinimo" => '0',
                "estoqMaximo" => '0',
				"usuarioLogin" => '0'
			);

            if(verificarParam($resultado, $lista) == 1){
                //Fazendo os seters
                $this->setDescricao($resultado->descricao);
                $this->setUnidMedida($resultado->unidMedida);
                $this->setEstoqMinimo($resultado->estoqMinimo);
                $this->setEstoqMaximo($resultado->estoqMaximo);
                $this->setUsuarioLogin($resultado->usuarioLogin);

                //Faremos uma validação para sabermos se todos os dados
				//foram enviados corretamente
                if (trim($this->getUnidMedida()) == ''){
					$retorno = array('codigo' => 2,
									'msg' => 'Unidade de medida não informada.');
				}elseif (trim($this->getDescricao()) == ''){
					$retorno = array('codigo' => 4,
									'msg' => 'Descrição não informada.');
				}elseif (trim($this->getUsuarioLogin() == '')){
					$retorno = array('codigo' => 5,
									'msg' => 'Usuário não informado');
                }elseif (trim($this->getEstoqMinimo()) == ''){
                    $retorno = array('codigo' => 11,
                                    'msg' => 'Estoque mínimo nao informado.');
                }elseif (trim($this->getEstoqMaximo()) == ''){
                    $retorno = array('codigo' => 12,
                                    'msg' => 'Estoque maximo nao informado.');
                }elseif (trim($this->getEstoqMinimo()) == trim($this->getEstoqMaximo())){
                    $retorno = array('codigo' => 13,
                                    'msg' => 'Estoque mínimo e maximo são iguais.');
                }elseif ($this->getEstoqMinimo() > $this->getEstoqMaximo()){
                    $retorno = array('codigo' => 14,
                                    'msg' => 'Estoque mínimo maior que o maximo.');
                }else{
                    //Realizo a instância da Model
					$this->load->model('m_produtos');

					//Atributo $retorno recebe array com informações
					$retorno = $this->m_produtos->inserir($this->getDescricao(), $this->getUnidMedida(), $this->getUsuarioLogin(), $this->getEstoqMinimo(), $this->getEstoqMaximo());	
                }
        }
    }catch (Exception $e){
			$retorno = array('codigo' => 0,
				'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',
				$e->getMessage());
	}
    }
    public function consultar(){		
		//Código, Descrição,Unidade de medida e Usuário que criou
		//recebidos via JSON e colocados em variáveis
		//Retornos possíveis:
		//1 - Dados consultados corretamente (Banco)
		//2 - Quantidade de caracteres da Unidade de medida é superior a 3 (FrontEnd)	
		//6 - Dados não encontrados (Banco)
		try{
			$json = file_get_contents('php://input');
			$resultado = json_decode($json);

			//Array com os dados que deverão vir do Front
			$lista = array(
                "codigo" => '0',
                "descricao" => '0',
                "unidMedida" => '0',
                "usuarioLogin" => '0'				
			);

			if (verificarParam($resultado, $lista) == 1) {	
				//Fazendo os seters
				$this->setCodigo($resultado->codigo);
				$this->setDescricao($resultado->descricao);
				$this->setUnidMedida($resultado->unidMedida);
				$this->setUsuarioLogin($resultado->usuarioLogin);			

				
				//Realizo a instância da Model
				$this->load->model('m_produtos');
				//Atributo $retorno recebe array com informações
				//da consulta dos dados
				$retorno = $this->m_produtos->consultar($this->getCodigo(),$this->getDescricao(), $this->getUnidMedida(), 
				                                          $this->getUsuarioLogin());	
				
			}else {
				$retorno = array(
					'codigo' => 99,
					'msg' => 'Os campos vindos do FrontEnd não representam 
					          o método de consulta. Verifique.'
				);
			}	
		}catch (Exception $e){
			$retorno = array('codigo' => 0,
							 'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',
							$e->getMessage());
		}
		//Retorno no formato JSON
		echo json_encode($retorno);
	}

    	public function alterar(){
		//Código, Unidade de medida e Descrição
		//recebidos via JSON e colocadas em variáveis
		//Retornos possíveis:
		//1 - Dado(s) alterado(s) corretamente (Banco)
		//2 - Faltou informar o codigo (FrontEnd)		
		//3 - Quantidade de caracteres da unidade de medida é superior a 3 (FrontEnd)
		//4 - Unidade de medida ou Descrição não informadas, aí não tem o que alterar (FrontEnd)
		//5 - Usuário não informado (FrontEnd)		
		//6 - Dados não encontrados (Banco)
		//7 - Houve problema no salvamento do LOG, mas a unidade foi inclusa (LOG)	
		try{
			$json = file_get_contents('php://input');
			$resultado = json_decode($json);

			//Array com os dados que deverão vir do Front
			$lista = array(
				"codigo" => '0',
				"descricao" => '0',
				"unidMedida" => '0',
                "usuarioLogin" => '0'			
			);

			if (verificarParam($resultado, $lista) == 1) {	
				//Fazendo os seters
				$this->setCodigo($resultado->codigo);
				$this->setUnidMedida($resultado->unidMedida);
				$this->setDescricao($resultado->descricao);	
				$this->setUsuarioLogin($resultado->usuarioLogin);
			
				//Faremos uma validação para sabermos se os dados
				//foram enviados corretamente
				if (trim($this->getCodigo()) == '' || trim($this->getCodigo()) == 0){
					$retorno = array('codigo' => 2,
									'msg' => 'Codigo não informado.');
				}elseif (strlen(trim($this->getUnidMedida())) > 3){
					$retorno = array('codigo' => 3,
									'msg' => 'Unidade de medida pode conter no máximo 3 caracteres.');
				}elseif (trim($this->getDescricao()) == '' && trim($this->getUnidMedida()) == ''){
					$retorno = array('codigo' => 4,
									'msg' => 'Unidade de medida ou Descrição não foram informadas.');
				}elseif (trim($this->getUsuarioLogin() == '')){
					$retorno = array('codigo' => 5,
									'msg' => 'Usuário não informado');
				}else{
					//Realizo a instância da Model
					$this->load->model('m_unidmedida');

					//Atributo $retorno recebe array com informações
					//da validação do acesso
					$retorno = $this->m_unidmedida->alterar($this->getCodigo(), $this->getUnidMedida(), 
														    $this->getDescricao(), $this->getUsuarioLogin());	
				}
			}else {
				$retorno = array(
					'codigo' => 99,
					'msg' => 'Os campos vindos do FrontEnd não representam 
					          o método de alteração. Verifique.'
				);
			}	
		}catch (Exception $e){
			$retorno = array('codigo' => 0,
							 'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',
							$e->getMessage());
		}
		//Retorno no formato JSON
		echo json_encode($retorno);
	}

    	public function desativar(){
		//Código da unidade recebido via JSON e colocado em variável
		//Retornos possíveis:
		//1 - Unidade desativada corretamente (Banco)
		//2 - Código não informado;
		//3 - Existem produtos cadastrados com essa unidade de medida
		//5 - Usuário não informado (FrontEnd)					
		//6 - Dados não encontrados (Banco)
		//7 - Houve problema no salvamento do LOG, mas a unidade foi alterada (LOG)	
		try{
			$json = file_get_contents('php://input');
			$resultado = json_decode($json);

			//Array com os dados que deverão vir do Front
			$lista = array(
				"codigo" => '0',			
				"usuarioLogin" => '0'				
			);
			
			if (verificarParam($resultado, $lista) == 1) {	
				//Fazendo os seters
				$this->setCodigo($resultado->codigo);			
				$this->setUsuarioLogin($resultado->usuarioLogin);

				//Validação para tipo de usuário que deverá ser ADMINISTRADOR, COMUM ou VAZIO
				if (trim($this->getCodigo() == '') || trim($this->getCodigo() == 0) ){
					$retorno = array('codigo' => 2,
									'msg' => 'Código da unidade não informado');
				}elseif (trim($this->getUsuarioLogin() == '')){
					$retorno = array('codigo' => 5,
									'msg' => 'Usuário não informado');
				}else{		
					//Realizo a instância da Model
					$this->load->model('m_produtos');

					//Atributo $retorno recebe array com informações			
					$retorno = $this->m_produtos->desativar($this->getCodigo(), $this->getUsuarioLogin());	
				}
			}else {
				$retorno = array(
					'codigo' => 99,
					'msg' => 'Os campos vindos do FrontEnd não representam 
							o método de desativação. Verifique.'
				);
			}
		}catch (Exception $e){
			$retorno = array('codigo' => 0,
							 'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',
							$e->getMessage());
		}	
		//Retorno no formato JSON
		echo json_encode($retorno);		

    }
}