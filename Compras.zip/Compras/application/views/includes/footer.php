  <script type="text/javascript" src="<?= base_url('assets/js/sweetalert.min.js')?>"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/bootstrap-table.min.js')?>"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/bootstrap-table-pt-BR.min.js')?>"></script>
	<script type="text/javascript" src="<?= base_url('assets/js/button-checkbox.js')?>"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/main.js')?>"></script>
	<script type="text/javascript" src="<?= base_url('assets/js/funcoes_gerais.js')?>"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/bootstrapValidator.min.js')?>"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/jasny-bootstrap.min.js')?>"></script>
  


