<html>
  <h2 class="text-center" style="margin-bottom: 30px;"><img src="<?php echo base_url('assets/img/etec.png'); ?>" width="200"></h3>
  <div class="row" style="margin-top: 50px; margin-bottom: 400px;">
    <div class="col-lg-12 col-md-offset-3">
    <label style="margin-left: 5px; margin-right: 5px;">“Sistema de compras desenvolvido para a disciplina PW II - 2º DSN.” </label>
    </br>
    <label style="margin-left: 5px; margin-right: 5px;">Professor Marcos Costa de Sousa</label>
    </div>
  </div>
</html>
