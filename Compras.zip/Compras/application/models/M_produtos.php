<?php
defined('BASEPATH') or exit('No direct script access allowed');

class m_produtos extends CI_Model {
	public function inserir($descricao, $unidMedida, $usuario, $estoqMinimo, $estoqMaximo){
    // Inicializar $dados com valor padrão
    $dados = array('codigo' => -1, 'msg' => 'Nenhuma operação realizada.');
    try {
        // Atributo $retorno recebe array com informações
        $ret_usuario = $this->verificaUsuario($usuario);

        // Validação se o usuário está com status válido
        if ($ret_usuario['codigo'] == 8 || $ret_usuario['codigo'] == 9) {
            $dados = $ret_usuario; // Retorno para controller com problema do usuário
        } else {
            // Verificar se a unidade de medida já está cadastrada
            $ret_produtos = $this->verificaUM($unidMedida);

            if ($ret_produtos['codigo'] == 2) {
                // Query de inserção dos dados
                $sql = "insert into produtos (descricao, unid_medida, usucria, estoqMaximo, estoqMinimo)
                        values ('$descricao', '$unidMedida', '$usuario', '$estoqMaximo', '$estoqMinimo')";
                $this->db->query($sql);

                // Verificar se a inserção ocorreu com sucesso
                if ($this->db->affected_rows() > 0) {
                    // Inserção no log
                    $this->load->model('m_log');
                    $retorno_log = $this->m_log->inserir_log($usuario, $sql);

                    if ($retorno_log['codigo'] == 1) {
                        $dados = array('codigo' => 1, 'msg' => 'Produto cadastrado corretamente');
                    } else {
                        $dados = array(
                            'codigo' => 7,
                            'msg' => 'Houve algum problema no salvamento do Log, porém, Produto adicionado corretamente'
                        );
                    }
                } else {
                    $dados = array(
                        'codigo' => 6,
                        'msg' => 'Houve algum problema na inserção na tabela de produtos $atributos'
                    );
                }
            } else {
                $dados = $ret_produtos; // Retorno de erro na verificação de unidade de medida
            }
        }
    } catch (Exception $e) {
        $dados = array(
            'codigo' => 00,
            'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ' . $e->getMessage()
        );
    }

    // Retorna o array $dados com informações
    return $dados;
	}

    	public function consultar($codigo, $descricao, $unidMedida, $usuarioLogin){
		//--------------------------------------------------
		//Função que servirá para quatro tipos de consulta:
		//  * Para todos as unidades de medida;
		//  * Para uma determinada sigla de unidade;
		//  * Para um código de unidade de medida;
		//  * Para descrição da unidade de medida;
		//--------------------------------------------------
		try{
			//Query para consultar dados de acordo com parâmetros passados		
			$sql = "select * from produtos where estatus = '' ";

			if($codigo != '' && $codigo != 0) {
				$sql = $sql . "and cod_produto = '$codigo' ";
			}

            if($descricao != ''){
				$sql = $sql . "and descricao like '%$descricao%' ";
			}

			if($unidMedida != ''){
				$sql = $sql . "and unid_medida = '$unidMedida' ";
			}

            if($usuarioLogin != ''){
                $sql = $sql . "and usucria = '$usuarioLogin' ";
            }
			

			$retorno = $this->db->query($sql);

			//Verificar se a consulta ocorreu com sucesso
			if($retorno->num_rows() > 0){
				$dados = array('codigo' => 1,
							'msg' => 'Consulta efetuada com sucesso',
							'dados' => $retorno->result());			
			}else{
				$dados = array('codigo' => 6,
							'msg' => 'Dados não encontrados');
			}
		}catch (Exception $e) {
			$dados = array('codigo' => 00,
							'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',  
									$e->getMessage(), "\n");
		}
		//Envia o array $dados com as informações tratadas
		//acima pela estrutura de decisão if
		return $dados;
	}

    	public function alterar($codigo, $descricao, $unidMedida, $usuario){
		try{
			if (trim($descricao) != ''){
				//Verificar se a unidade de medida já não está cadastrada
				$ret_produtos = $this->verificaUM($unidMedida);

				if ($ret_produtos['codigo'] == 2){
					$dados = $ret_produtos;	
					return $dados;
				}
			}

			//Query de atualização dos dados
			if (trim($unidMedida) != '' && trim($descricao) != '') {
				$sql = "update produtos set unid_medida = '$unidMedida', descricao = '$descricao'
						where cod_produto = '$codigo'";			
			}elseif (trim($unidMedida) != '') {
				$sql = "update produtos set unid_medida = '$unidMedida' where cod_produto = '$codigo'";
			}else{
				$sql = "update produtos set descricao = '$descricao' where cod_produto = '$codigo'";
			}

			$this->db->query($sql);

			//Verificar se a atualização ocorreu com sucesso
			if($this->db->affected_rows() > 0){
				//Fazemos a inserção no Log na nuvem
				//Fazemos a instância da model M_log
				$this->load->model('m_log');

				//Fazemos a chamada do método de inserção do Log
				$retorno_log = $this->m_log->inserir_log($usuario, $sql);

				if ($retorno_log['codigo'] == 1){
					$dados = array('codigo' => 1,
								'msg' => 'Produto atualizado corretamente');
				}else{
					$dados = array('codigo' => 7,
								'msg' => 'Houve algum problema no salvamento do Log, porém, 
											produto cadastrado corretamente');
				}			
			}else{
				$dados = array('codigo' => 6,
							'msg' => 'Não houve alteração no registro especificado.');
			}

		}catch (Exception $e) {
			$dados = array('codigo' => 00,
							'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',  
									$e->getMessage(), "\n");
		}
		//Envia o array $dados com as informações tratadas
		//acima pela estrutura de decisão if
		return $dados;
	}

    public function desativar($codigo, $usuario){
		try{
			
				//Query de atualização dos dados
				$sql2 = "update produtos set estatus = 'D' where cod_produto = '$codigo'";

				$this->db->query($sql2);

				//Verificar se a atualização ocorreu com sucesso
				if($this->db->affected_rows() > 0){
					//Fazemos a inserção no Log na nuvem
					//Fazemos a instância da model M_log
					$this->load->model('m_log');

					//Fazemos a chamada do método de inserção do Log
					$retorno_log = $this->m_log->inserir_log($usuario, $sql2);			

					if ($retorno_log['codigo'] == 1){
						$dados = array('codigo' => 1,
									'msg' => 'Produto DESATIVADO corretamente');
					}else{
						$dados = array('codigo' => 8,
									'msg' => 'Houve algum problema no salvamento do Log, porém, 
												produto desativado corretamente');
					}
					
				}else{
					$dados = array('codigo' => 7,
								'msg' => 'Houve algum problema na DESATIVAÇÃO do produto');
				}
			
		}catch (Exception $e) {
			$dados = array('codigo' => 00,
							'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',  
									$e->getMessage(), "\n");
		}
		//Envia o array $dados com as informações tratadas
		//acima pela estrutura de decisão if
		return $dados;
	}



    private function verificaUsuario($usuario) {
		try{
			//Função PRIVADA só para verificar se o usuário existe
			//em nosso banco de dados na tabela de usuários
			//Retornos:
			//1 - Usuário cadastrado na base de dados
			//8 - Usuário desativado no banco de dados
			//9 - Usuário não encontrado		

			$sql = "select * from usuarios where usuario = '$usuario'  ";

			$retorno = $this->db->query($sql);

			//Verificar se a consulta trouxe algum usuario
			if($retorno->num_rows() > 0){
				//Verifico o status do usuário
				if($retorno->row()->estatus == 'D'){
					//Não se pode cadastrar o usuário
					$dados = array('codigo' => 8,
							'msg' => 'Não pode cadastrar, usuário informado está DESATIVADO');
				}else{
					$dados = array('codigo' => 1,
								'msg' => 'Usuário ativo na base de dados');
				}
			}else{
				$dados = array('codigo' => 9,
								'msg' => 'Usuário não encontrado na base de dados');
			}
		}catch (Exception $e) {
			$dados = array('codigo' => 00,
							'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',  
									$e->getMessage(), "\n");
		}
		//Envia o array $dados com as informações tratadas
		//acima pela estrutura de decisão if
		return $dados;
	}

	public function verificaUM($unidMedida) {
    try {
        // Inicializa a variável $dados com um valor padrão
        $dados = array('codigo' => -1, 'msg' => 'Nenhuma operação realizada.');

        // Query para consultar a unidade de medida
        $sql = "select * from unid_medida
                where cod_unidade = '$unidMedida'
                and estatus = '' ";
        
        $retorno = $this->db->query($sql);

        if ($retorno->num_rows() == 0) {
            $dados = array(
                'codigo' => 2,
                'msg' => 'Unidade de medida não cadastrada.'
            );
        } else {
            $dados = array(
                'codigo' => 1,
                'msg' => 'Unidade de medida encontrada.'
            );
        }
    } catch (Exception $e) {
        $dados = array(
            'codigo' => 0,
            'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ' . $e->getMessage()
        );
    }

    // Retorna o array $dados
    return $dados;
		}
}